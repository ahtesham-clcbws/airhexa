<div class="sidebar-side col-xl-3 col-lg-4 col-md-12 col-sm-12">
    <aside class="sidebar services-sidebar">

        <!-- Category Widget -->
        <div class="sidebar-widget categories">
            <div class="widget-content">
                <!-- Services Category -->
                <ul class="services-categories">
                    <?= view('Components/WebServicesMenu'); ?>
                </ul>
            </div>
        </div>

        <!--Brochures Box-->
        <div class="brochures-box">
            <div class="inner">
                <h4>Download Brochures</h4>
                <div class="text">
                    Pleasure and praising pain was born and I will give you a complete account.
                </div>
                <!-- <a class="theme-btn btn-style-one" href="#"><span class="btn-title"><i class="fa fa-file-pdf"></i> Info Company</span></a> -->
                <a class="theme-btn btn-style-one" href="/pdf/Air-Hexa-Air-Solutions-LLP-Profile.pdf" download><span class="btn-title"><i class="fa fa-file-pdf"></i> Brochure Newest</span></a>
            </div>
        </div>
    </aside>
</div>