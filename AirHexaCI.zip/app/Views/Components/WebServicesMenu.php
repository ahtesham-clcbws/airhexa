<li class="<?= $_SERVER['REQUEST_URI'] === route_to('electricalSystemsService') ? 'active' : '' ?>">
    <a href="<?= route_to('electricalSystemsService') ?>">Electrical System</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('fireFightingSystemService') ? 'active' : '' ?>">
    <a href="<?= route_to('fireFightingSystemService') ?>">Fire Fighting System</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('plumbingSystemService') ? 'active' : '' ?>">
    <a href="<?= route_to('plumbingSystemService') ?>">Plumbing System</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('hvacService') ? 'active' : '' ?>">
    <a href="<?= route_to('hvacService') ?>">HVAC</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('solarSystemService') ? 'active' : '' ?>">
    <a href="<?= route_to('solarSystemService') ?>">Solar System</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('civilAndInteriorWorksService') ? 'active' : '' ?>">
    <a href="<?= route_to('civilAndInteriorWorksService') ?>">Civil &amp; Interior Works</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('cctvAndSecuritySurveillanceService') ? 'active' : '' ?>">
    <a href="<?= route_to('cctvAndSecuritySurveillanceService') ?>">CCTV &amp; Security Surveillance</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('accessControlBiometricService') ? 'active' : '' ?>">
    <a href="<?= route_to('accessControlBiometricService') ?>">Access Control &amp; Biometric</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('automationSolutionsService') ? 'active' : '' ?>">
    <a href="<?= route_to('automationSolutionsService') ?>">Automation Solutions</a>
</li>
<li class="<?= $_SERVER['REQUEST_URI'] === route_to('intercomAndNetworkingService') ? 'active' : '' ?>">
    <a href="<?= route_to('intercomAndNetworkingService') ?>">Intercom &amp; Networking</a>
</li>