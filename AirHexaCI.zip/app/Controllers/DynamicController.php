<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class DynamicController extends BaseController
{
    public function index()
    {
        //
    }
}
